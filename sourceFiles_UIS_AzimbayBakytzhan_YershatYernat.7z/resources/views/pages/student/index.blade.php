@extends('layouts.student')

@section('content')
    <div class="jumbotron text-center">
        {{ Breadcrumbs::render('home') }}
        <h1 class="display-4">Welcome, student!</h1>
    
    </div>
@endsection